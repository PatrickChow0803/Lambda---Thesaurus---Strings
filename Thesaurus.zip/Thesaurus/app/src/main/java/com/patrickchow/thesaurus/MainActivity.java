package com.patrickchow.thesaurus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView    myText;
    Button      myButton;
    EditText    myEdit;


    //Find the synonyms in an array.
    public static String[] synonyms(String [][]arrayOfWords, String target){

        String [] emptyArray = {"NULL, No synonyms were found."};

        //To loop through the 2D array and find a word that matches the target
        for(int row = 0; row < arrayOfWords.length; row++){
            for(int col = 0; col < arrayOfWords[row].length; col++){
                //If a word is found, keep track of that row that contains the word and fill up the array.
                if(arrayOfWords[row][col].equals(target)){
                    int rowHolder = row;
                    String [] foundArray = new String[arrayOfWords[row].length];
                    //Place the words in the row into the new array.
                    for(int i = 0; i <arrayOfWords[rowHolder].length; i++)
                        foundArray[i] = arrayOfWords[rowHolder][i];
                    return  foundArray;
                }
            }
        }
        return emptyArray;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myText = findViewById(R.id.textViewID);
        myButton = findViewById(R.id.buttonID);
        myEdit = findViewById(R.id.editTextID);

        final String[][] arrayOfWords = new String[][] { {"swift",  "abrupt", "expeditious", "hasty", "nimble", "quick", "rapid", "speedy", "sudden", "unexpected"},
                {"objective", "detached", "disinterested", "dispassionate", "equitable", "evenhanded", "nonpartisan", "open-minded", "unbiased"},
                {"calculate", "adjust", "appraise", "consider", "count", "determine", "forecast", "gauge", "guess", "measure", "multiply", "reckon", "subtract", "tally", "weigh", "work out"},
                {"create", "build", "conceive", "constitute", "construct", "design", "devise", "discover", "establish", "forge", "form"} };

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    myText.setText(""); //Resets the word each time button is clicked.
                    String myWord = myEdit.getText().toString();
                    String [] myStringArray = synonyms(arrayOfWords,  myWord);
                    for(int i=0; i<myStringArray.length; i++) {
                        myText.append(myStringArray[i]);
                        myText.append("\n");
                    }
                }
            }
        );
    }
}
